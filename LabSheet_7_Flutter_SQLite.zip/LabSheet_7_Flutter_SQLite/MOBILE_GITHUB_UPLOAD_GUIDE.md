# Mobile GitHub Upload Guide

1. Extract `LabSheet_7_Flutter_SQLite.zip` on your phone.
2. Open https://github.com/uttamtyagi01/Mobile_Application_Development
3. In the mobile browser, choose **Add file → Upload files**. If unavailable, enable **Desktop site**.
4. Upload the `Program_01` through `Program_17` folders. If folder upload is unsupported, upload each program folder's files or use a mobile Git client.
5. Commit with message: `Add LabSheet 7 SQLite CRUD programs`.

Do not upload `.dart_tool/` or `build/` folders. This ZIP contains source files only.

To run one program, open its folder in Android Studio, run `flutter pub get`, then `flutter run`.
