# LabSheet 7 — Program 4: Insert record from TextFields

## Run on Android
1. Open this folder as a Flutter project in Android Studio.
2. Run `flutter pub get`.
3. Connect an Android phone with USB debugging enabled, or use an emulator.
4. Run `flutter run`.

## Dependencies
- `sqflite`
- `path`

The app creates a local SQLite database named `students.db`. Each Program folder is a separate Flutter app and includes its own `pubspec.yaml` and `lib/main.dart`.
