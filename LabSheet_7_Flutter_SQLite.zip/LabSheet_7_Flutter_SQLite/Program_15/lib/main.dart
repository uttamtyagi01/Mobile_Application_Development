import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

void main() => runApp(const LabApp());

class LabApp extends StatelessWidget {
  const LabApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'LabSheet 7 - Program 15',
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo), useMaterial3: true),
    home: const ProgramPage(),
  );
}

class Student {
  final int? id;
  final String name;
  final String rollNumber;
  final String course;
  const Student({this.id, required this.name, required this.rollNumber, required this.course});
  Map<String, Object?> toMap() => {'id': id, 'name': name, 'roll_number': rollNumber, 'course': course};
  factory Student.fromMap(Map<String, Object?> map) => Student(
    id: map['id'] as int?,
    name: map['name'] as String,
    rollNumber: map['roll_number'] as String,
    course: map['course'] as String,
  );
}

class DatabaseHelper {
  DatabaseHelper._();
  static final DatabaseHelper instance = DatabaseHelper._();
  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    final path = p.join(await getDatabasesPath(), 'students.db');
    _database = await openDatabase(path, version: 1, onCreate: (db, version) async {
      await db.execute('''
        CREATE TABLE students(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          roll_number TEXT NOT NULL UNIQUE,
          course TEXT NOT NULL
        )
      ''');
    });
    return _database!;
  }

  Future<void> createTable() async {
    final db = await database;
    await db.execute('''
      CREATE TABLE IF NOT EXISTS students(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        roll_number TEXT NOT NULL UNIQUE,
        course TEXT NOT NULL
      )
    ''');
  }

  Future<int> insert(Student student) async {
    final db = await database;
    final values = student.toMap()..remove('id');
    return db.insert('students', values, conflictAlgorithm: ConflictAlgorithm.replace);
  }
  Future<int> rawInsert(Student student) async {
    final db = await database;
    return db.rawInsert(
      'INSERT OR REPLACE INTO students(name, roll_number, course) VALUES(?, ?, ?)',
      [student.name, student.rollNumber, student.course],
    );
  }
  Future<List<Student>> getAll({String? orderBy, String? course}) async {
    final db = await database;
    final rows = await db.query('students',
      where: course == null ? null : 'course = ?',
      whereArgs: course == null ? null : [course],
      orderBy: orderBy);
    return rows.map(Student.fromMap).toList();
  }
  Future<List<Student>> rawGetAll() async {
    final db = await database;
    final rows = await db.rawQuery('SELECT * FROM students ORDER BY id DESC');
    return rows.map(Student.fromMap).toList();
  }
  Future<int> update(Student student) async {
    final db = await database;
    final values = student.toMap()..remove('id');
    return db.update('students', values, where: 'id = ?', whereArgs: [student.id]);
  }
  Future<int> delete(int id) async {
    final db = await database;
    return db.delete('students', where: 'id = ?', whereArgs: [id]);
  }
  Future<int> deleteAll() async => (await database).delete('students');
  Future<Student?> findByRoll(String roll) async {
    final rows = await (await database).query('students',
      where: 'roll_number = ?', whereArgs: [roll], limit: 1);
    return rows.isEmpty ? null : Student.fromMap(rows.first);
  }
  Future<int> count() async {
    final rows = await (await database).rawQuery('SELECT COUNT(*) AS total FROM students');
    return Sqflite.firstIntValue(rows) ?? 0;
  }
}

class ProgramPage extends StatefulWidget {
  const ProgramPage({super.key});
  @override
  State<ProgramPage> createState() => _ProgramPageState();
}

class _ProgramPageState extends State<ProgramPage> {
  String message = 'Ready';
  List<Student> students = [];
  final nameController = TextEditingController();
  final rollController = TextEditingController();
  final courseController = TextEditingController();
  final searchController = TextEditingController();
  final updateIdController = TextEditingController();
  final updateNameController = TextEditingController();
  String selectedCourse = 'BCA';
  int total = 0;
  Student? foundStudent;

  @override
  void initState() {
    super.initState();
    _initialise();
  }
  Future<void> _initialise() async {
    try {
      await DatabaseHelper.instance.database;
      if (!mounted) return;
      setState(() => message = 'Database ready.');
      await loadStudents();
      await loadCount();
    } catch (e) {
      if (mounted) setState(() => message = 'Error: $e');
    }
  }
  @override
  void dispose() {
    nameController.dispose(); rollController.dispose(); courseController.dispose();
    searchController.dispose(); updateIdController.dispose(); updateNameController.dispose();
    super.dispose();
  }

  Future<void> loadStudents({String? orderBy, String? course}) async {
    final result = await DatabaseHelper.instance.getAll(orderBy: orderBy, course: course);
    if (mounted) setState(() => students = result);
  }
  Future<void> loadRawStudents() async {
    final result = await DatabaseHelper.instance.rawGetAll();
    if (mounted) setState(() => students = result);
  }
  Future<void> loadCount() async {
    final result = await DatabaseHelper.instance.count();
    if (mounted) setState(() => total = result);
  }
  Future<void> addStudent({bool raw = false, bool fixed = false}) async {
    final student = Student(
      name: fixed ? 'Aarav Sharma' : nameController.text.trim(),
      rollNumber: fixed ? '101' : rollController.text.trim(),
      course: fixed ? 'BCA' : (courseController.text.trim().isEmpty ? selectedCourse : courseController.text.trim()),
    );
    if (student.name.isEmpty || student.rollNumber.isEmpty || student.course.isEmpty) {
      setState(() => message = 'Please enter name, roll number and course.');
      return;
    }
    try {
      if (raw) { await DatabaseHelper.instance.rawInsert(student); }
      else { await DatabaseHelper.instance.insert(student); }
      nameController.clear(); rollController.clear(); courseController.clear();
      await loadStudents(); await loadCount();
      if (mounted) setState(() => message = 'Student saved successfully.');
    } catch (e) {
      if (mounted) setState(() => message = 'Could not save record: $e');
    }
  }
  Future<void> searchStudent() async {
    final result = await DatabaseHelper.instance.findByRoll(searchController.text.trim());
    if (mounted) setState(() { foundStudent = result; message = result == null ? 'No student found.' : 'Student found.'; });
  }
  Future<void> deleteStudent(Student student) async {
    if (student.id != null) await DatabaseHelper.instance.delete(student.id!);
    await loadStudents(); await loadCount();
    if (mounted) setState(() => message = 'Record deleted.');
  }
  Future<void> updateStudent() async {
    final id = int.tryParse(updateIdController.text.trim());
    if (id == null || updateNameController.text.trim().isEmpty) {
      setState(() => message = 'Enter a valid ID and new name.');
      return;
    }
    final rows = await DatabaseHelper.instance.getAll();
    final old = rows.where((s) => s.id == id).toList();
    if (old.isEmpty) { setState(() => message = 'No record with that ID.'); return; }
    final student = Student(id: id, name: updateNameController.text.trim(),
      rollNumber: old.first.rollNumber, course: old.first.course);
    await DatabaseHelper.instance.update(student);
    await loadStudents(); await loadCount();
    if (mounted) setState(() => message = 'Record updated.');
  }

  Widget field(String label, TextEditingController controller, {TextInputType? keyboard}) =>
    Padding(padding: const EdgeInsets.symmetric(vertical: 5), child: TextField(
      controller: controller, keyboardType: keyboard,
      decoration: InputDecoration(labelText: label, border: const OutlineInputBorder())));

  Widget studentList() => students.isEmpty
    ? const Padding(padding: EdgeInsets.all(12), child: Text('No records yet. Add a student to begin.'))
    : ListView.builder(
        shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
        itemCount: students.length,
        itemBuilder: (context, index) {
          final s = students[index];
          return Card(child: ListTile(
            title: Text('${s.name} (Roll: ${s.rollNumber})'),
            subtitle: Text('ID: ${s.id} • Course: ${s.course}'),
            trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => deleteStudent(s)),
          ));
        });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('LabSheet 7 - Program 15')),
      body: SingleChildScrollView(padding: const EdgeInsets.all(16), child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('Program 15: Student model with toMap() and fromMap()', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          Text(message, style: const TextStyle(color: Colors.indigo)),
          const SizedBox(height: 12),
          field('Student name', nameController),
          field('Roll number', rollController),
          field('Course', courseController),
          ElevatedButton(onPressed: () => addStudent(), child: const Text('Insert Student Model')),
          const SizedBox(height: 8),
          ElevatedButton(onPressed: loadStudents, child: const Text('Retrieve and Convert fromMap()')),
          studentList(),
        ],
      )),
    );
  }
}
