# Flutter SQLite CRUD — LabSheet 7

This ZIP contains 17 independent Flutter projects, one for each program in LabSheet 7.

## Programs
- `Program_01` — Create SQLite database
- `Program_02` — Create students table
- `Program_03` — Insert record using insert()
- `Program_04` — Insert record from TextFields
- `Program_05` — Insert using rawInsert()
- `Program_06` — Read records using query() and ListView
- `Program_07` — Read records using rawQuery()
- `Program_08` — Update an existing record
- `Program_09` — Delete a student record
- `Program_10` — Delete all records
- `Program_11` — Search by roll number using WHERE
- `Program_12` — Filter students by selected course
- `Program_13` — Sort records by name ascending
- `Program_14` — Count records in students table
- `Program_15` — Student model with toMap() and fromMap()
- `Program_16` — DatabaseHelper for all CRUD operations
- `Program_17` — Student Record Management Application (CRUD)

## Run a program
Open the required `Program_XX` folder in Android Studio, then run:

```bash
flutter pub get
flutter run
```

Each folder has its own `pubspec.yaml`, `lib/main.dart`, and `README.md`.
